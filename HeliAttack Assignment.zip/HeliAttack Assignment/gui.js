// GUI class
//----------------------------------
var GUI = function(game) {
	this.game = game;
	var health = 10;
	var lives = 3;
	var missiles = 3;
	var score = 0;
	
	// GUI panels
	this.topLeft = document.getElementById("gui-top-left");
	this.topCenter = document.getElementById("gui-top-center");
	this.topRight = document.getElementById("gui-top-right");
	this.bottomLeft = document.getElementById("gui-bottom-left");
	this.bottomCenter = document.getElementById("gui-bottom-center");
	this.bottomRight = document.getElementById("gui-bottom-right");
	
	this.render = function() {
		// Render Health
		this.topCenter.innerHTML = "Health: " + health;
		// Render Lives
		this.topLeft.innerHTML = "Lives: " + lives;
		// Render Missiles
		this.bottomLeft.innerHTML = "Missiles: " + missiles;
		// Render Score
		this.topRight.innerHTML = "Score: " + score;
		// Render mini-map (Extra Credit
	}
}