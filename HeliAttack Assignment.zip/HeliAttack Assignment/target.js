// Target.js
var PI = Math.PI;

var Target = function(x, y, scrolling) {
	this.x = x;
	this.y = y;
	this.uy = y-50;
	this.by = y+50;
	this.scrolling = scrolling;
	this.speed = 0.05;
	this.direction = 1;
	this.radius = 20;
}

Target.prototype = {
	update: function(elapsedTime) {
		if(this.y <= this.uy) {
			this.direction = 1;
		}
		else if(this.y >= this.by) {
			this.direction = -1;
		}
		
		this.y += this.speed * this.direction * elapsedTime;
		
		if(this.scrolling.right == true) {
			this.x -= 5;
			this.tx -= 5;
		}
		else if(this.scrolling.left == true) {
			this.x += 5;
			this.tx += 5;
		}
	},
	
	render: function(context) {
		context.save();
		context.strokeStyle = "#000000";
		context.fillStyle = "#512888";
		context.beginPath();
		context.arc(this.x, this.y, this.radius, 0, 2*PI, false);
		context.fill();
		context.stroke();
		context.restore();
	},
	
	destroy: function() {
		this.destroyed = true;
	}
}