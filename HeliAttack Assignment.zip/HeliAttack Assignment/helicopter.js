
// Helicopter class
//----------------------------------
var Helicopter = function(game, x, y, grid) {
	this.game = game;
	this.x = x;
	this.y = y;
	this.grid = grid;
	this.velocity = 1;
	this.health = 100;
	this.pitch_angle = 0;
	this.turret_angle = 0;
	this.bulletElapsedTime = 500;
	this.missiles = 3;
	this.sprite_sheet = new Image();
	this.sprite_sheet.src = "images/helicopter.png";
	this.bullets = [];
	this.missiles =[];
	this.mouse = { x: this.x+50, y: this.y };
	this.scrolling = game.scrolling;
	this.id = 0;
};

Helicopter.prototype = {
	x: 0,
	y: 0,
	velocity: 0,
	
	render: function(context) {
		// Render helicopter with pitch angle, missiles, and targeted turret
		context.save();
		context.translate(this.x, this.y);
		context.rotate(this.pitch_angle);
		context.translate(-65, -4);
		
		//Turret
		context.save();
		context.translate(90, 35);
		context.rotate(this.turret_angle);
		context.drawImage(this.sprite_sheet, 100, 56, 25, 8, -5, 0, 25, 8);
		context.restore();
		
		// Heli
		context.drawImage(this.sprite_sheet, 0, 0, 131, 52, 0, 0, 131, 52);
		context.translate(56, 35);
		
		// Missiles
		for(i = 0; i < this.missiles; i++) {
			context.translate(2,2);
		    context.drawImage(this.sprite_sheet, 75, 56, 17, 8, 0, 0, 17, 8);
		}
		context.restore();
		
		// Bullets
		this.bullets.forEach(function(bullet) {
			bullet.render(context);
		});
		
		// Missiles in the air
		this.missiles.forEach(function(missile) {
			missile.render(context);
		});
	},
	
	update: function(elapsedTime, inputState) {
		self = this;
		
		// Move the helicopter
		this.move(inputState);

		// Rotate the turret
		this.turret_angle = Math.atan((this.mouse.y - this.y) / (this.mouse.x - this.x));
		if(this.mouse.y - this.y < 0) {
			this.turret_angle += 2 * PI;
		}
		if(this.mouse.x - this.x < 0) {
			this.turret_angle += PI;
		}
		
		// Fire weapons
		this.bulletElapsedTime += elapsedTime;
		if(this.fireBullets == true && this.bulletElapsedTime >= 100) {
			b = new Bullet(this.x, this.y, this.mouse.x, this.mouse.y, this.scrolling, this.id++);
			this.bullets.push(b);
			this.grid.add(b);
			this.bulletElapsedTime = 0;
		}
		
		this.bullets.forEach(function(bullet) {
			bullet.update(elapsedTime);
			if(bullet.destroyed == true) {
				self.grid.remove(bullet);
				index = self.bullets.indexOf(bullet);
				self.bullets.splice(index, 1);
			}
		});

		this.missiles.forEach(function(missile) {
			missile.update(elapsedTime, this.scrolling);
			if(missile.destroyed == true) {
				self.grid.remove(missile);
				index = self.missiles.indexOf(missile);
				self.missiles.splice(index, 1);
			}
		});
		
	},
	
	move: function(inputState) {
		this.scrolling.left = false;
		this.scrolling.right = false;
		if(inputState.up) {
			if(this.y > 50) {
				this.y -= this.velocity * 5;
			}
		} else if(inputState.down) {
			if(this.y < 350) {
				this.y += this.velocity * 5;
			}
		}
		if(inputState.left) {
			this.pitch_angle = -Math.PI/10;
			if(this.x > 100) {
				this.x -= this.velocity * 5;
			}
			else {
				this.game.sx -= this.velocity * 5; // scroll the background
				this.scrolling.left = true; // tell the missils and bullets to adjust for the scrolling
			}
		} else if(inputState.right) {
			this.pitch_angle = Math.PI/8;
		    if(this.x < 400) {
				this.x += this.velocity * 5;
			}
			else {
				this.game.sx += this.velocity * 5;
				this.scrolling.right = true;
			}
		} else {
			this.pitch_angle = 0;
		}
	},
	
	handleClick: function(e, mouse) {
		this.mouse = mouse;
		// Fire bullets till release
		if(e.which == 1) {
			this.fireBullets = true;
		}
		if(e.which == 2) {
			console.log(this.bullets);
			console.log(this.missiles);
			console.log(this.grid);
		}
		// Fire one missile
		else if(e.which == 3) {
			this.missiles.push(new Missile(this.x, this.y, mouse.x, mouse.y, this.scrolling, this.id++));
		}
	},
	
	// Stop firing bullets on mouse left up
	handleMouseUp: function(e) {
		if(e.which == 1) {
			this.fireBullets = false;
		}
	}
};